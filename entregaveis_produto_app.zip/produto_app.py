\
    """
    produto_app.py
    Aplicação desktop (Tkinter) para CRUD de produtos em memória.
    """
    import tkinter as tk
    from tkinter import ttk, messagebox
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Produto:
        id: int
        nome: str
        preco: float
        quantidade: int

        def __str__(self):
            return f"Produto(id={self.id}, nome='{self.nome}', preco={self.preco}, quantidade={self.quantidade})"

    class ProdutoController:
        def __init__(self):
            self.produtos: List[Produto] = []
            self._next_id = 1

        def adicionar(self, produto: Produto) -> None:
            produto.id = self._next_id
            self._next_id += 1
            self.produtos.append(produto)

        def listar(self) -> List[Produto]:
            return list(self.produtos)

        def atualizar(self, id: int, produto: Produto) -> bool:
            for i, p in enumerate(self.produtos):
                if p.id == id:
                    produto.id = id
                    self.produtos[i] = produto
                    return True
            return False

        def remover(self, id: int) -> bool:
            for i, p in enumerate(self.produtos):
                if p.id == id:
                    del self.produtos[i]
                    return True
            return False

    class ProdutoView:
        def __init__(self, root, controller: ProdutoController):
            self.controller = controller
            self.root = root
            self.root.title("Gerenciador de Produtos")

            frame = ttk.Frame(root, padding=10)
            frame.grid(sticky="nsew")

            ttk.Label(frame, text="Nome:").grid(row=0, column=0, sticky="w")
            self.nome_var = tk.StringVar()
            self.entry_nome = ttk.Entry(frame, textvariable=self.nome_var, width=30)
            self.entry_nome.grid(row=0, column=1, sticky="w")

            ttk.Label(frame, text="Preço:").grid(row=1, column=0, sticky="w")
            self.preco_var = tk.StringVar()
            self.entry_preco = ttk.Entry(frame, textvariable=self.preco_var, width=15)
            self.entry_preco.grid(row=1, column=1, sticky="w")

            ttk.Label(frame, text="Quantidade:").grid(row=2, column=0, sticky="w")
            self.quant_var = tk.StringVar()
            self.entry_quant = ttk.Entry(frame, textvariable=self.quant_var, width=15)
            self.entry_quant.grid(row=2, column=1, sticky="w")

            btn_frame = ttk.Frame(frame)
            btn_frame.grid(row=3, column=0, columnspan=2, pady=(8,12), sticky="w")

            self.btn_add = ttk.Button(btn_frame, text="Adicionar", command=self.adicionar)
            self.btn_add.grid(row=0, column=0, padx=4)
            self.btn_list = ttk.Button(btn_frame, text="Listar", command=self.listar)
            self.btn_list.grid(row=0, column=1, padx=4)
            self.btn_update = ttk.Button(btn_frame, text="Atualizar", command=self.atualizar)
            self.btn_update.grid(row=0, column=2, padx=4)
            self.btn_remove = ttk.Button(btn_frame, text="Remover", command=self.remover)
            self.btn_remove.grid(row=0, column=3, padx=4)

            columns = ("id", "nome", "preco", "quantidade")
            self.tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse", height=8)
            self.tree.heading("id", text="ID")
            self.tree.heading("nome", text="Nome")
            self.tree.heading("preco", text="Preço")
            self.tree.heading("quantidade", text="Quantidade")
            self.tree.column("id", width=40, anchor="center")
            self.tree.column("nome", width=200)
            self.tree.column("preco", width=80, anchor="e")
            self.tree.column("quantidade", width=90, anchor="center")
            self.tree.grid(row=4, column=0, columnspan=2, sticky="nsew")

            self.tree.bind("<<TreeviewSelect>>", self.on_select)

            root.rowconfigure(0, weight=1)
            root.columnconfigure(0, weight=1)
            frame.rowconfigure(4, weight=1)
            frame.columnconfigure(1, weight=1)

            self.listar()

        def limpar_campos(self):
            self.nome_var.set("")
            self.preco_var.set("")
            self.quant_var.set("")

        def adicionar(self):
            try:
                nome = self.nome_var.get().strip()
                preco = float(self.preco_var.get())
                quant = int(self.quant_var.get())
            except Exception:
                messagebox.showerror("Erro", "Dados inválidos. Verifique os campos.")
                return

            if not nome:
                messagebox.showerror("Erro", "Nome não pode ficar vazio.")
                return

            p = Produto(id=0, nome=nome, preco=preco, quantidade=quant)
            self.controller.adicionar(p)
            messagebox.showinfo("Sucesso", f"Produto '{nome}' adicionado.")
            self.limpar_campos()
            self.listar()

        def listar(self):
            for row in self.tree.get_children():
                self.tree.delete(row)
            for p in self.controller.listar():
                self.tree.insert("", "end", values=(p.id, p.nome, f"{p.preco:.2f}", p.quantidade))

        def on_select(self, event):
            sel = self.tree.selection()
            if not sel:
                return
            vals = self.tree.item(sel[0], "values")
            self.nome_var.set(vals[1])
            self.preco_var.set(vals[2])
            self.quant_var.set(vals[3])

        def atualizar(self):
            sel = self.tree.selection()
            if not sel:
                messagebox.showwarning("Atenção", "Selecione um produto para atualizar.")
                return
            vals = self.tree.item(sel[0], "values")
            try:
                id_sel = int(vals[0])
                nome = self.nome_var.get().strip()
                preco = float(self.preco_var.get())
                quant = int(self.quant_var.get())
            except Exception:
                messagebox.showerror("Erro", "Dados inválidos para atualização.")
                return

            new_p = Produto(id=id_sel, nome=nome, preco=preco, quantidade=quant)
            ok = self.controller.atualizar(id_sel, new_p)
            if ok:
                messagebox.showinfo("Sucesso", f"Produto ID {id_sel} atualizado.")
                self.limpar_campos()
                self.listar()
            else:
                messagebox.showerror("Erro", "Falha ao atualizar produto.")

        def remover(self):
            sel = self.tree.selection()
            if not sel:
                messagebox.showwarning("Atenção", "Selecione um produto para remover.")
                return
            vals = self.tree.item(sel[0], "values")
            id_sel = int(vals[0])
            confirm = messagebox.askyesno("Confirmar", f"Remover produto ID {id_sel}?")
            if not confirm:
                return
            ok = self.controller.remover(id_sel)
            if ok:
                messagebox.showinfo("Removido", f"Produto ID {id_sel} removido.")
                self.limpar_campos()
                self.listar()
            else:
                messagebox.showerror("Erro", "Falha ao remover produto.")

    if __name__ == "__main__":
        root = tk.Tk()
        controller = ProdutoController()
        view = ProdutoView(root, controller)
        root.mainloop()
