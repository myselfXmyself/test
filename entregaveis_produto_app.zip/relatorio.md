# Relatório — Gerenciador de Produtos (1 página)

**Estrutura do projeto**
- produto_app.py : aplicação completa em Python (Tkinter) contendo:
  - `Produto` (modelo)
  - `ProdutoController` (controlador CRUD em memória)
  - `ProdutoView` (interface gráfica usando ttk.Treeview)

**Descrição dos métodos do CRUD**
- `adicionar(produto: Produto)` : atribui um id único e adiciona o produto à lista.
- `listar()` : retorna uma cópia da lista de produtos.
- `atualizar(id: int, produto: Produto) -> bool` : procura produto pelo id e substitui seus dados; retorna True se atualizado.
- `remover(id: int) -> bool` : remove o produto com o id informado; retorna True se removido.

**Decisões de design tomadas**
- Linguagem: Python (Tkinter) escolhida pela simplicidade e portabilidade.
- Armazenamento: lista em memória (`list`); IDs autogerados.
- Interface: `ttk.Treeview` para exibição tabular.
- Validação: conversão de tipos e checagem de campos vazios com feedback via `messagebox`.
- UX: após cada operação os campos são limpos e a lista é atualizada automaticamente.
