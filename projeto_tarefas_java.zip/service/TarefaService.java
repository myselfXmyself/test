package service;

import java.time.LocalDate;
import java.util.List;

import model.Tarefa;
import repository.TarefaRepository;

public class TarefaService {

    private TarefaRepository repo;

    public TarefaService(TarefaRepository repo) {
        this.repo = repo;
    }

    public void cadastrar(String titulo, String descricao, LocalDate dataConclusao) {
        repo.adicionar(new Tarefa(0, titulo, descricao, dataConclusao));
    }

    public List<Tarefa> listar() {
        return repo.listar();
    }

    public boolean atualizar(int id, String titulo, String descricao, LocalDate dataConclusao) {
        return repo.atualizar(id, new Tarefa(id, titulo, descricao, dataConclusao));
    }

    public boolean remover(int id) {
        return repo.remover(id);
    }
}
