Este projeto é um sistema simples de gerenciamento de tarefas via console, desenvolvido em Java, seguindo boas práticas de Programação Orientada a Objetos (POO) e uma estrutura organizada em camadas (Model, Repository, Service e App).

O usuário pode realizar operações CRUD completas:

Cadastrar nova tarefa

Listar todas as tarefas

Atualizar uma tarefa existente

Excluir uma tarefa

Encerrar o programa

Cada tarefa possui:

id (inteiro, autoincrementado)

título

descrição

data de conclusão (LocalDate)

Estrutura:

src/
 └── main/
      └── java/
           ├── model/
           │     └── Tarefa.java
           ├── repository/
           │     └── TarefaRepository.java
           ├── service/
           │     └── TarefaService.java
           └── app/
                 └── Main.java

model model

Contém a classe Tarefa, responsável por representar a entidade principal do sistema.

repository

Armazena e gerencia as tarefas em memória (Lista).

service

Aplica regras de negócio e coordena as operações CRUD.

 app

Contém a classe Main, responsável apenas por exibir o menu e interagir com o usuário.

execução

1. Faça o download do arquivo ZIP

Baixe o projeto que enviei:

projeto_tarefas_java.zip

Extraia-o em qualquer pasta do seu computador.

Tecnologias 

Java 17 (ou qualquer versão igual ou superior a 11)

Paradigma: Programação Orientada a Objetos (POO)

Bibliotecas-padrão do Java (java.util, java.time, java.io, etc.)

Console (terminal) como interface de execução

ompilar

Abra o terminal dentro da pasta src/main/java e execute:

javac app/Main.java


Se quiser compilar tudo de uma vez:

find . -name "*.java" > sources.txt
javac @sources.txt


Isso irá gerar os arquivos .class.

e depois execute

Java app.Main

Autor:

Pedro Miguel