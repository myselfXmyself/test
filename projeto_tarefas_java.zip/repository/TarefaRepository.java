package repository;

import java.util.ArrayList;
import java.util.List;
import model.Tarefa;

public class TarefaRepository {
    private List<Tarefa> tarefas = new ArrayList<>();
    private int nextId = 1;

    public void adicionar(Tarefa tarefa) {
        tarefa.setId(nextId++);
        tarefas.add(tarefa);
    }

    public List<Tarefa> listar() {
        return new ArrayList<>(tarefas);
    }

    public boolean atualizar(int id, Tarefa nova) {
        for (int i = 0; i < tarefas.size(); i++) {
            if (tarefas.get(i).getId() == id) {
                nova.setId(id);
                tarefas.set(i, nova);
                return true;
            }
        }
        return false;
    }

    public boolean remover(int id) {
        return tarefas.removeIf(t -> t.getId() == id);
    }
}
