package app;

import java.time.LocalDate;
import java.util.Scanner;

import repository.TarefaRepository;
import service.TarefaService;
import model.Tarefa;

public class Main {

    public static void main(String[] args) {
        TarefaRepository repo = new TarefaRepository();
        TarefaService service = new TarefaService(repo);
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== MENU ===");
            System.out.println("1 - Cadastrar tarefa");
            System.out.println("2 - Listar tarefas");
            System.out.println("3 - Atualizar tarefa");
            System.out.println("4 - Excluir tarefa");
            System.out.println("5 - Sair");
            System.out.print("Escolha: ");

            int opc = Integer.parseInt(sc.nextLine());

            switch (opc) {
                case 1:
                    System.out.print("Título: ");
                    String titulo = sc.nextLine();
                    System.out.print("Descrição: ");
                    String desc = sc.nextLine();
                    System.out.print("Data de conclusão (AAAA-MM-DD): ");
                    LocalDate data = LocalDate.parse(sc.nextLine());
                    service.cadastrar(titulo, desc, data);
                    System.out.println("Tarefa cadastrada!");
                    break;

                case 2:
                    System.out.println("\n--- Tarefas ---");
                    for (Tarefa t : service.listar()) {
                        System.out.println(t);
                    }
                    break;

                case 3:
                    System.out.print("ID da tarefa a atualizar: ");
                    int idUp = Integer.parseInt(sc.nextLine());
                    System.out.print("Novo título: ");
                    String t2 = sc.nextLine();
                    System.out.print("Nova descrição: ");
                    String d2 = sc.nextLine();
                    System.out.print("Nova data (AAAA-MM-DD): ");
                    LocalDate data2 = LocalDate.parse(sc.nextLine());
                    if (service.atualizar(idUp, t2, d2, data2))
                        System.out.println("Tarefa atualizada!");
                    else
                        System.out.println("ID não encontrado.");
                    break;

                case 4:
                    System.out.print("ID da tarefa a excluir: ");
                    int idDel = Integer.parseInt(sc.nextLine());
                    if (service.remover(idDel))
                        System.out.println("Tarefa removida!");
                    else
                        System.out.println("ID não encontrado.");
                    break;

                case 5:
                    System.out.println("Saindo...");
                    sc.close();
                    return;

                default:
                    System.out.println("Opção inválida!");
            }
        }
    }
}
